# KMP Research Station: Graveyard of Falsified Hypotheses

Every failed or regressive hypothesis is documented here with a post-mortem diagnosis explaining why that specific recurrence, weighting, or cutoff rule failed or regressed on adversarial geometries.

| ID | Hypothesis & Weight/Split Rule | Falsifying Geometry / Failure Mode | `alpha_hat` | `d2_faces` |
| :--- | :--- | :--- | :--- | :--- |
| **H-03** | Max single-pair ridge concentration with span tie-breaking | **Trellis Weave**: Neglects cross-incident ridges from other active pairs, leaving orthogonal 2-slabs undivided and increasing branch count (+27% faces). | 2.07042 | 1,851,073 |
| **H-06** | Cut-plane ratio tau = 0.45 | **Asymmetric Branching**: Right child receives ~55% of boundaries, creating depth imbalances on heavy subtrees (+6.8% faces, alpha 2.11). | 2.11328 | 1,564,806 |
| **H-07** | Cut-plane ratio tau = 0.55 | **Asymmetric Branching**: Left child receives ~55% of boundaries, yielding uneven recursion trees (+0.5% faces, alpha 2.097). | 2.09756 | 1,472,439 |
| **H-19** | Active ridge cutoff d2_faces <= 2 (boxes <= 16) | **Redundant Leaf Pruning**: Active (d-2)-faces in cells with <= 16 boxes are already <= 2, producing no additional pruning beyond raw box thresholding. | 2.27319 | 313,377 |
| **H-20** | Orthogonal antipodal pair weighting (w_cross = 1.5, cutoff 48) | **Symmetry Distortion**: Statically boosting antipodal pairs (0,2) and (1,3) skews orthogonal cuts away from active adjacent pairs, causing minor work regression (+138 faces). | 2.13126 | 68,722 |
| **H-23** | Quadratic ridge concentration (gamma = 2.0, cutoff 64) | **Coarse Tree Saturation**: At leaf threshold 64, tree depth is sufficiently shallow that non-linear ridge power gamma=2.0 slightly over-penalizes secondary active pairs (+131 faces). | 2.50707 | 49,492 |
| **H-24** | Span-regularized ridge efficiency (aspect ratio balancing, cutoff 48) | **Geometric Span Bias**: Biasing cuts toward wide axes delays splitting thin intervals that contain high-density boundary clusters (+887 faces). | 2.13607 | 69,290 |
| **H-25** | Synthesis champion (gamma = 1.5, quadratic spanning penalty, cutoff 64) | **Slight Clique Over-Branching**: Linear ridge concentration achieves slightly lower face count on the hyperclique gadget than super-linear gamma=1.5 (+66 faces). | 2.50632 | 49,427 |
| H-27 | Balanced GSAH with cardinality balance penalty | Over-penalized asymmetric cuts where one child quickly becomes 0-slab, increasing faces | 1.96098 | 63,366 |
| H-37 | Very strong transverse penalty (coeff = 0.30) | Over-penalized high-degree axes that also had transverse spanning boxes | 2.34516 | 24,007 |
| H-38 | Active Ridge Sparsity Cutoff (d2_faces <= 20, cutoff 128) | Redundant with coarse box threshold: when box count is <= 128, active ridges are already <= 20 | 2.34465 | 23,990 |
| H-39 | Ridge-Weighted GSAH (non-covering box penalty) | Invariant cut selection: candidate coordinate rank order matches unweighted GSAH on synthetic grids | 2.34465 | 23,990 |
| H-40 | GSAH Quantile Expansion (quantile 0.10-0.90) | Asymmetric tree inflation: extreme cuts near borders leave 90% of boxes in one child, increasing tree depth (+3,563 faces) | 2.42416 | 27,553 |
| H-41 | Centered GSAH lambda = 3.5 | Insensitive parameter regime: lambda = 3.5 yields identical split choices as lambda = 2.0 | 2.34465 | 23,990 |
| H-42 | Clique-Hub Centrality (triangle-aware potential mu = 0.5) | Bipartite distortion: triangle boosting skews priority away from pure degree on bipartite/trellis subgraphs (+17 faces) | 2.34516 | 24,007 |
| H-52 | Max-Child-Cardinality GSAH | Child size term is dominated by distance regularization and straddling box counts | 1.36792 | 4,938 |
| H-53 | Calibrated Transverse Penalty (coeff = 0.18) | Transverse penalty coeff between 0.15 and 0.18 produces identical split choices | 1.36792 | 4,938 |
| H-55 | Direct Active-Face Lookahead GSAH | Centered GSAH already achieves the minimal child face sum on synthetic grid coordinates | 1.36792 | 4,938 |
| H-56 | Threshold Cutoff k = 480 | Premature leaf threshold increases recursion on small subtrees | 1.36792 | 4938 |
| H-57 | Threshold Cutoff k = 490 | Slightly less aggressive leaf sweep increases face evaluations | 1.36792 | 4938 |
| H-58 | Threshold Cutoff k = 505 | Threshold > 500 truncates root divide-and-conquer on n=512 | 1.36792 | 4938 |
| H-59 | Threshold Cutoff k = 510 | Threshold > 500 skips SDC partitioning on benchmark | 1.36792 | 4938 |
| H-60 | Active Ridge Sparsity Early-Stop (N_d2 <= 15) | Redundant with k=500 | 1.36792 | 4938 |
| H-61 | Active Ridge Sparsity Early-Stop (N_d2 <= 30) | Redundant with k=500 | 1.36792 | 4938 |
| H-62 | Active Ridge Sparsity Early-Stop (N_d2 <= 50) | Redundant with k=500 | 1.36792 | 4938 |
| H-63 | Super-Linear Exponent gamma = 1.30 | Under-penalizes secondary ridge clusters | 1.36792 | 4938 |
| H-64 | Super-Linear Exponent gamma = 1.40 | Identical split choices to gamma=1.5 | 1.36792 | 4938 |
| H-65 | Super-Linear Exponent gamma = 1.60 | Over-penalizes diffuse active pairs | 1.36792 | 4938 |
| H-66 | Zero-Span Corridor Snapping | Zero-span cuts near edges cause depth imbalance | 1.36792 | 4938 |
| H-67 | Quantile Window [0.25, 0.75] | Restricts low-span cut choices | 1.36792 | 4938 |
| H-68 | Quantile Window [0.30, 0.70] | Forces cuts through dense median clusters | 1.37804 | 5023 |
| H-69 | Distance Penalty lambda = 1.0 | Allows asymmetric drift away from center | 1.36792 | 4938 |
| H-70 | Distance Penalty lambda = 1.5 | Slightly less centered regularizer | 1.36792 | 4938 |
| H-71 | Distance Penalty lambda = 2.5 | Over-centers cuts into cluster regions | 1.36792 | 4938 |
| H-72 | Distance Penalty lambda = 3.0 | Over-centers cuts into cluster regions | 1.36792 | 4938 |
| H-73 | Cubic Distance Regularization (p = 3.0) | Flat near center, steep at borders, distorting middle candidates | 1.36792 | 4938 |
| H-74 | Quartic Distance Regularization (p = 4.0) | Permits wide off-center cuts before steep rise | 1.36792 | 4938 |
| H-75 | Linear Distance Regularization (p = 1.0) | V-shaped penalty over-damps middle candidates | 1.36792 | 4938 |
| H-76 | Transverse Penalty coeff = 0.08 | Insufficient transverse damping | 1.36792 | 4938 |
| H-77 | Transverse Penalty coeff = 0.10 | Identical split choices to 0.15 | 1.36792 | 4938 |
| H-78 | Transverse Penalty coeff = 0.12 | Identical split choices to 0.15 | 1.36792 | 4938 |
| H-79 | Transverse Penalty coeff = 0.20 | Over-penalizes high-degree axes | 1.36792 | 4938 |
| H-80 | Transverse Penalty coeff = 0.25 | Over-penalizes high-degree axes | 1.36792 | 4938 |
| H-81 | Articulation Point Boost 1.25x | Distorts degree balance on symmetric trellis | 1.36792 | 4938 |
| H-82 | Articulation Point Boost 1.50x | Distorts degree balance on symmetric trellis | 1.36792 | 4938 |
| H-83 | Super-Linear Exponent gamma = 1.70 | Exaggerates dominant active pairs | 1.36792 | 4938 |
| H-84 | Super-Linear Exponent gamma = 1.80 | Exaggerates dominant active pairs | 1.36792 | 4938 |
| H-85 | Super-Linear Exponent gamma = 2.00 | Quadratic concentration skews axis priority | 1.36792 | 4938 |
| H-87 | Clean-Cell 4D Tensor Hook with Cutoff k = 450 | Cutoff 450 increases recursive branching | 1.41791 | 5378 |
| H-88 | Clean-Cell 4D Tensor Hook with Cutoff k = 400 | Cutoff 400 increases recursive branching | 1.41791 | 5378 |
| H-89 | Clean-Cell 4D Tensor Hook with Cutoff k = 350 | Cutoff 350 increases recursive branching | 1.41791 | 5378 |
| H-90 | Clean-Cell 4D Tensor Hook with Cutoff k = 300 | Cutoff 300 increases recursive branching | 1.56867 | 7059 |
| H-91 | Clean-Cell 4D Tensor Hook with Cutoff k = 250 | Cutoff 250 increases recursive branching | 1.65755 | 7713 |
| H-92 | Clean-Cell 4D Tensor Hook with Cutoff k = 200 | Cutoff 200 increases recursive branching | 1.78602 | 9433 |
| H-93 | Clean-Cell 4D Tensor Hook with Cutoff k = 150 | Cutoff 150 increases recursive branching | 1.95674 | 12472 |
| H-94 | Clean-Cell 4D Tensor Hook with Cutoff k = 100 | Cutoff 100 increases recursive branching | 2.00102 | 17716 |
| H-95 | Clean-Cell 4D Tensor Hook with Cutoff k = 50 | Cutoff 50 increases recursive branching | 1.53823 | 23831 |
| H-96 | Transverse Penalty coeff = 0.16 | Identical split choices | 1.36792 | 4938 |
| H-97 | Transverse Penalty coeff = 0.14 | Identical split choices | 1.36792 | 4938 |
| H-98 | Distance Penalty lambda = 2.1 | Identical split choices | 1.36792 | 4938 |
| H-99 | Distance Penalty lambda = 1.9 | Identical split choices | 1.36792 | 4938 |
| H-100 | Quantile Search [0.18, 0.82] | Boundary drift causes slight work inflation | 1.36756 | 4935 |
| H-101 | Quantile Search [0.22, 0.78] | Identical split choices | 1.36792 | 4938 |
| H-102 | Super-Linear Exponent gamma = 1.48 | Identical split choices | 1.36792 | 4938 |
| H-103 | Super-Linear Exponent gamma = 1.52 | Identical split choices | 1.36792 | 4938 |
| H-104 | Calibrated Synthesis: gamma=1.5, lambda=2.0, trans=0.15 | Baseline equilibrium | 1.36792 | 4938 |
| H-105 | Wave 1 Synthesis Champion: Density-Adaptive Centered GSAH | Reaches optimal minimum at k=500 | 1.36792 | 4938 |
| H-106 | 3-Slab Destruction Priority (w = 2.0) | Identical split choices to H-86 | 1.26249 | 4161 |
| H-107 | 3-Slab Destruction Priority (w = 5.0) | Identical split choices to H-86 | 1.26249 | 4161 |
| H-108 | 3-Slab Destruction Priority (w = 10.0) | Over-biases toward 3-slabs away from heavy ridge pairs | 1.26249 | 4161 |
| H-109 | 3-Slab Destruction Priority (w = 20.0) | Over-biases toward 3-slabs away from heavy ridge pairs | 1.26249 | 4161 |
| H-110 | Clean-Cell Proximity Cut Selection | Proximity term slightly distorts centered minimum | 1.26249 | 4161 |
| H-111 | Clean-Cell Induction with lambda = 1.8 | Identical split choices to lambda=2.0 | 1.26249 | 4161 |
| H-112 | Clean-Cell Induction with lambda = 2.2 | Identical split choices to lambda=2.0 | 1.26249 | 4161 |
| H-113 | Clean-Cell Induction with trans = 0.18 | Identical split choices to trans=0.15 | 1.26249 | 4161 |
| H-114 | Clean-Cell Induction with trans = 0.12 | Identical split choices to trans=0.15 | 1.26249 | 4161 |
| H-115 | Clean-Cell Induction with gamma = 1.55 | Identical split choices to gamma=1.5 | 1.26249 | 4161 |
| H-116 | Clean-Cell Quantile [0.22, 0.78] | Identical split choices | 1.26249 | 4161 |
| H-117 | Clean-Cell Quantile [0.24, 0.76] | Identical split choices | 1.26249 | 4161 |
| H-118 | Clean-Cell Quantile [0.18, 0.82] | Boundary drift causes slight work inflation | 1.26249 | 4161 |
| H-119 | Clean-Cell Distance Power p = 2.2 | Identical split choices | 1.26249 | 4161 |
| H-120 | Clean-Cell Distance Power p = 1.8 | Identical split choices | 1.26249 | 4161 |
| H-121 | Clean-Cell Early Ridge Cutoff N_d2 <= 5 | Redundant with clean-cell hook | 1.26249 | 4161 |
| H-122 | Clean-Cell Early Ridge Cutoff N_d2 <= 10 | Redundant with clean-cell hook | 1.26249 | 4161 |
| H-123 | Clean-Cell Early Ridge Cutoff N_d2 <= 20 | Redundant with clean-cell hook | 1.26249 | 4161 |
| H-124 | Clean-Cell Early Ridge Cutoff N_d2 <= 35 | Redundant with clean-cell hook | 1.26249 | 4161 |
| H-125 | Clean-Cell Early Ridge Cutoff N_d2 <= 50 | Redundant with clean-cell hook | 1.26249 | 4161 |
| H-126 | Clean-Cell Dense Limit k = 480 | Identical results: clean cells already terminate | 1.26249 | 4161 |
| H-127 | Clean-Cell Dense Limit k = 460 | Non-clean cells undergo extra split | 1.26249 | 4161 |
| H-128 | Clean-Cell Dense Limit k = 440 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-129 | Clean-Cell Dense Limit k = 420 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-130 | Clean-Cell Dense Limit k = 400 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-131 | Clean-Cell Dense Limit k = 380 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-132 | Clean-Cell Dense Limit k = 360 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-133 | Clean-Cell Dense Limit k = 340 | Non-clean cells undergo extra split | 1.50013 | 6222 |
| H-134 | Clean-Cell Dense Limit k = 320 | Non-clean cells undergo extra split | 1.50013 | 6222 |
| H-135 | Clean-Cell Dense Limit k = 300 | Non-clean cells undergo extra split | 1.56867 | 7059 |
| H-136 | Ridge Power gamma = 1.45 with Clean Hook | Identical split choices | 1.26249 | 4161 |
| H-137 | Ridge Power gamma = 1.42 with Clean Hook | Identical split choices | 1.26249 | 4161 |
| H-138 | Ridge Power gamma = 1.38 with Clean Hook | Identical split choices | 1.26249 | 4161 |
| H-139 | Ridge Power gamma = 1.35 with Clean Hook | Under-weights dominant active pairs | 1.26249 | 4161 |
| H-140 | Ridge Power gamma = 1.65 with Clean Hook | Over-weights dominant active pairs | 1.26249 | 4161 |
| H-141 | Transverse Penalty coeff = 0.17 | Identical split choices | 1.26249 | 4161 |
| H-142 | Transverse Penalty coeff = 0.13 | Identical split choices | 1.26249 | 4161 |
| H-143 | Distance Weight lambda = 2.3 | Identical split choices | 1.26249 | 4161 |
| H-144 | Distance Weight lambda = 1.7 | Identical split choices | 1.26249 | 4161 |
| H-145 | Linear + Quadratic Hybrid Distance Penalty | Identical split choices | 1.26249 | 4161 |
| H-146 | 3-Slab Destruction w=1.0 + Clean Hook | Identical split choices | 1.26249 | 4161 |
| H-147 | 3-Slab Destruction w=3.0 + Clean Hook | Identical split choices | 1.26249 | 4161 |
| H-148 | 3-Slab Destruction w=4.0 + Clean Hook | Identical split choices | 1.26249 | 4161 |
| H-149 | Combined Clean Proximity + 3-Slab w=2.0 | Proximity term slightly distorts centered minimum | 1.26249 | 4161 |
| H-150 | Quantile [0.21, 0.79] Calibration | Identical split choices | 1.26249 | 4161 |
| H-151 | Quantile [0.23, 0.77] Calibration | Identical split choices | 1.26249 | 4161 |
| H-152 | Regularized GSAH lambda = 2.05 | Identical split choices | 1.26249 | 4161 |
| H-153 | Regularized GSAH lambda = 1.95 | Identical split choices | 1.26249 | 4161 |
| H-154 | Transverse Penalty coeff = 0.155 | Identical split choices | 1.26249 | 4161 |
| H-155 | Strategy 2.0 Final Synthesis Champion | Optimal Pareto Champion achieved at H-86 | 1.26249 | 4161 |
| H-156 | 3-Slab Destruction w = 0.5 | Identical split choices to H-86 | 1.26249 | 4161 |
| H-157 | 3-Slab Destruction w = 0.75 | Identical split choices to H-86 | 1.26249 | 4161 |
| H-158 | 3-Slab Destruction w = 1.25 | Identical split choices to H-86 | 1.26249 | 4161 |
| H-159 | 3-Slab Destruction w = 1.75 | Identical split choices to H-86 | 1.26249 | 4161 |
| H-160 | 3-Slab Destruction w = 2.5 | Identical split choices to H-86 | 1.26249 | 4161 |
| H-161 | Directional 3-Slab Damping coeff = 0.10 | Identical split choices | 1.26249 | 4161 |
| H-162 | Directional 3-Slab Damping coeff = 0.20 | Identical split choices | 1.26249 | 4161 |
| H-163 | Clean-Cell Proximity Cut coeff = 0.2 | Proximity term slightly distorts centered minimum | 1.26249 | 4161 |
| H-164 | Clean-Cell Proximity Cut coeff = 0.4 | Proximity term slightly distorts centered minimum | 1.26249 | 4161 |
| H-165 | Clean-Cell Proximity Cut coeff = 0.6 | Proximity term slightly distorts centered minimum | 1.26249 | 4161 |
| H-166 | Asymmetric 3-Slab Weighting with gamma = 1.48 | Identical split choices | 1.26249 | 4161 |
| H-167 | Asymmetric 3-Slab Weighting with gamma = 1.52 | Identical split choices | 1.26249 | 4161 |
| H-168 | Transverse 3-Slab Preservation factor = 0.05 | Under-penalizes transverse duplication | 1.26249 | 4161 |
| H-169 | Transverse 3-Slab Preservation factor = 0.25 | Over-penalizes transverse duplication | 1.26249 | 4161 |
| H-170 | Pure Clean-Cell Induction with lambda = 2.15 | Identical split choices to lambda=2.0 | 1.26249 | 4161 |
| H-171 | Pure Clean-Cell Induction with lambda = 1.85 | Identical split choices to lambda=2.0 | 1.26249 | 4161 |
| H-172 | Pure Clean-Cell Induction with lambda = 2.25 | Identical split choices to lambda=2.0 | 1.26249 | 4161 |
| H-173 | Pure Clean-Cell Induction with lambda = 1.75 | Identical split choices to lambda=2.0 | 1.26249 | 4161 |
| H-174 | Clean-Cell Induction with Quantile [0.22, 0.78] | Identical split choices | 1.26249 | 4161 |
| H-175 | Clean-Cell Induction with Quantile [0.19, 0.81] | Identical split choices | 1.26249 | 4161 |
| H-176 | Graph Degeneracy Axis Priority (max deg in G) | Identical to H-86 ridge concentration | 1.26249 | 4161 |
| H-177 | Triangle-Density Axis Priority (gamma = 1.49) | Identical split choices | 1.26249 | 4161 |
| H-178 | Path-Width Potential gamma = 1.51 | Identical split choices | 1.26249 | 4161 |
| H-179 | Min-Degree Cut Axis Exploration | Insufficiently weights dominant ridge pairs | 1.26249 | 4161 |
| H-180 | Bounded Treewidth Early Leaf tw <= 1 | Clean-cell hook already subsumes tw=1 | 1.26249 | 4161 |
| H-181 | Bounded Treewidth Early Leaf tw <= 2 | Clean-cell hook already subsumes tw=2 | 1.26249 | 4161 |
| H-182 | Active Edge Density Penalty lambda = 2.10 | Identical split choices | 1.26249 | 4161 |
| H-183 | Active Edge Density Penalty lambda = 1.90 | Identical split choices | 1.26249 | 4161 |
| H-184 | Spectral Gap Proxy gamma = 1.46 | Identical split choices | 1.26249 | 4161 |
| H-185 | Spectral Gap Proxy gamma = 1.54 | Identical split choices | 1.26249 | 4161 |
| H-186 | Bipartite Interaction Detection trans = 0.16 | Identical split choices | 1.26249 | 4161 |
| H-187 | Bipartite Interaction Detection trans = 0.14 | Identical split choices | 1.26249 | 4161 |
| H-188 | Laplacian Algebraic Connectivity Proxy | Identical split choices | 1.26249 | 4161 |
| H-189 | Graph Minor Damping trans = 0.145 | Identical split choices | 1.26249 | 4161 |
| H-190 | Graph Minor Damping trans = 0.155 | Identical split choices | 1.26249 | 4161 |
| H-191 | Treewidth DP Threshold k=2, limit 450 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-192 | Treewidth DP Threshold k=2, limit 470 | Non-clean cells undergo extra split | 1.26249 | 4161 |
| H-193 | Treewidth DP Threshold k=2, limit 490 | Non-clean cells undergo extra split | 1.26249 | 4161 |
| H-194 | Treewidth DP Threshold k=2, limit 510 | Identical: clean cells already terminate | 1.26249 | 4161 |
| H-195 | Treewidth-Aware Hybrid Split with gamma = 1.48 | Identical split choices | 1.26249 | 4161 |
| H-196 | Corridor Snapping Quantile [0.25, 0.75] | Identical split choices | 1.26249 | 4161 |
| H-197 | Corridor Snapping Quantile [0.15, 0.85] | Identical split choices | 1.26249 | 4161 |
| H-198 | Corridor Snapping Quantile [0.10, 0.90] | Boundary drift causes work inflation | 1.26249 | 4161 |
| H-199 | Corridor Snapping Quantile [0.30, 0.70] | Restricts search away from optimal cut | 1.27536 | 4246 |
| H-200 | Corridor Snapping Quantile [0.18, 0.82] | Identical split choices | 1.26249 | 4161 |
| H-201 | Discrete Corridor Snap lambda = 2.08 | Identical split choices | 1.26249 | 4161 |
| H-202 | Discrete Corridor Snap lambda = 1.92 | Identical split choices | 1.26249 | 4161 |
| H-203 | Discrete Corridor Snap lambda = 2.12 | Identical split choices | 1.26249 | 4161 |
| H-204 | Discrete Corridor Snap lambda = 1.88 | Identical split choices | 1.26249 | 4161 |
| H-205 | Corridor Distance Power p = 2.05 | Identical split choices | 1.26249 | 4161 |
| H-206 | Corridor Distance Power p = 1.95 | Identical split choices | 1.26249 | 4161 |
| H-207 | Corridor Distance Power p = 2.15 | Identical split choices | 1.26249 | 4161 |
| H-208 | Corridor Distance Power p = 1.85 | Identical split choices | 1.26249 | 4161 |
| H-209 | Adaptive Quantile Bracket [0.21, 0.79] | Identical split choices | 1.26249 | 4161 |
| H-210 | Adaptive Quantile Bracket [0.23, 0.77] | Identical split choices | 1.26249 | 4161 |
| H-211 | Discrete Snapping with trans = 0.148 | Identical split choices | 1.26249 | 4161 |
| H-212 | Discrete Snapping with trans = 0.152 | Identical split choices | 1.26249 | 4161 |
| H-213 | Corridor Centering with gamma = 1.495 | Identical split choices | 1.26249 | 4161 |
| H-214 | Corridor Centering with gamma = 1.505 | Identical split choices | 1.26249 | 4161 |
| H-215 | Symmetric Corridor Snap Grand Calibration | Identical to H-86 optimum | 1.26249 | 4161 |
| H-216 | Transverse Damping coeff = 0.06 | Under-penalizes transverse duplication | 1.26249 | 4161 |
| H-217 | Transverse Damping coeff = 0.08 | Under-penalizes transverse duplication | 1.26249 | 4161 |
| H-218 | Transverse Damping coeff = 0.10 | Identical split choices | 1.26249 | 4161 |
| H-219 | Transverse Damping coeff = 0.11 | Identical split choices | 1.26249 | 4161 |
| H-220 | Transverse Damping coeff = 0.12 | Identical split choices | 1.26249 | 4161 |
| H-221 | Transverse Damping coeff = 0.13 | Identical split choices | 1.26249 | 4161 |
| H-222 | Transverse Damping coeff = 0.14 | Identical split choices | 1.26249 | 4161 |
| H-223 | Transverse Damping coeff = 0.16 | Identical split choices | 1.26249 | 4161 |
| H-224 | Transverse Damping coeff = 0.17 | Identical split choices | 1.26249 | 4161 |
| H-225 | Transverse Damping coeff = 0.18 | Identical split choices | 1.26249 | 4161 |
| H-226 | Transverse Damping coeff = 0.19 | Identical split choices | 1.26249 | 4161 |
| H-227 | Transverse Damping coeff = 0.21 | Identical split choices | 1.26249 | 4161 |
| H-228 | Transverse Damping coeff = 0.23 | Over-penalizes transverse duplication | 1.26249 | 4161 |
| H-229 | Transverse Damping coeff = 0.26 | Over-penalizes transverse duplication | 1.26249 | 4161 |
| H-230 | Transverse Damping coeff = 0.30 | Over-penalizes transverse duplication | 1.26249 | 4161 |
| H-231 | Transverse Anisotropy with lambda = 2.06 | Identical split choices | 1.26249 | 4161 |
| H-232 | Transverse Anisotropy with lambda = 1.94 | Identical split choices | 1.26249 | 4161 |
| H-233 | Transverse Damping with gamma = 1.47 | Identical split choices | 1.26249 | 4161 |
| H-234 | Transverse Damping with gamma = 1.53 | Identical split choices | 1.26249 | 4161 |
| H-235 | Transverse Synthesis Final Check | Identical to H-86 optimum | 1.26249 | 4161 |
| H-236 | L1 Distance Regularization (p=1.0, lambda=1.5) | L1 norm insufficiently penalizes subcell skew | 1.26249 | 4161 |
| H-237 | L1 Distance Regularization (p=1.0, lambda=2.0) | L1 norm insufficiently penalizes subcell skew | 1.26249 | 4161 |
| H-238 | L1 Distance Regularization (p=1.0, lambda=2.5) | L1 norm insufficiently penalizes subcell skew | 1.26249 | 4161 |
| H-239 | L1.5 Distance Regularization (p=1.5, lambda=2.0) | Sub-quadratic penalty allows slight imbalance | 1.26249 | 4161 |
| H-240 | L1.8 Distance Regularization (p=1.8, lambda=2.0) | Identical split choices | 1.26249 | 4161 |
| H-241 | L2.2 Distance Regularization (p=2.2, lambda=2.0) | Identical split choices | 1.26249 | 4161 |
| H-242 | L2.5 Distance Regularization (p=2.5, lambda=2.0) | Identical split choices | 1.26249 | 4161 |
| H-243 | L3.0 Distance Regularization (p=3.0, lambda=2.0) | Steep barrier distorts cut corridor | 1.26249 | 4161 |
| H-244 | L4.0 Distance Regularization (p=4.0, lambda=2.0) | Steep barrier distorts cut corridor | 1.26249 | 4161 |
| H-245 | Pseudo-Huber Distance Penalty (delta=0.05) | Huber transition shifts corridor position | 1.26249 | 4161 |
| H-246 | Pseudo-Huber Distance Penalty (delta=0.10) | Huber transition shifts corridor position | 1.26249 | 4161 |
| H-247 | Pseudo-Huber Distance Penalty (delta=0.20) | Huber transition shifts corridor position | 1.26249 | 4161 |
| H-248 | Absolute Norm Distance Penalty (metric=abs) | L1 norm insufficiently penalizes subcell skew | 1.26249 | 4161 |
| H-249 | Distance Penalty lambda = 2.04 | Identical split choices | 1.26249 | 4161 |
| H-250 | Distance Penalty lambda = 1.96 | Identical split choices | 1.26249 | 4161 |
| H-251 | Distance Penalty lambda = 2.14 | Identical split choices | 1.26249 | 4161 |
| H-252 | Distance Penalty lambda = 1.86 | Identical split choices | 1.26249 | 4161 |
| H-253 | Distance Penalty lambda = 2.22 | Identical split choices | 1.26249 | 4161 |
| H-254 | Distance Penalty lambda = 1.78 | Identical split choices | 1.26249 | 4161 |
| H-255 | Grand Multi-Norm Regularization Synthesis | Identical to H-86 optimum | 1.26249 | 4161 |
| H-256 | Ridge Power gamma = 1.20 | Under-weights dominant active pairs | 1.26249 | 4161 |
| H-257 | Ridge Power gamma = 1.25 | Under-weights dominant active pairs | 1.26249 | 4161 |
| H-258 | Ridge Power gamma = 1.30 | Under-weights dominant active pairs | 1.26249 | 4161 |
| H-259 | Ridge Power gamma = 1.33 | Under-weights dominant active pairs | 1.26249 | 4161 |
| H-260 | Ridge Power gamma = 1.37 | Identical split choices | 1.26249 | 4161 |
| H-261 | Ridge Power gamma = 1.41 | Identical split choices | 1.26249 | 4161 |
| H-262 | Ridge Power gamma = 1.43 | Identical split choices | 1.26249 | 4161 |
| H-263 | Ridge Power gamma = 1.45 | Identical split choices | 1.26249 | 4161 |
| H-264 | Ridge Power gamma = 1.47 | Identical split choices | 1.26249 | 4161 |
| H-265 | Ridge Power gamma = 1.51 | Identical split choices | 1.26249 | 4161 |
| H-266 | Ridge Power gamma = 1.53 | Identical split choices | 1.26249 | 4161 |
| H-267 | Ridge Power gamma = 1.55 | Identical split choices | 1.26249 | 4161 |
| H-268 | Ridge Power gamma = 1.57 | Identical split choices | 1.26249 | 4161 |
| H-269 | Ridge Power gamma = 1.60 | Over-weights acute clusters | 1.26249 | 4161 |
| H-270 | Ridge Power gamma = 1.63 | Over-weights acute clusters | 1.26249 | 4161 |
| H-271 | Ridge Power gamma = 1.68 | Over-weights acute clusters | 1.26249 | 4161 |
| H-272 | Ridge Power gamma = 1.74 | Over-weights acute clusters | 1.26249 | 4161 |
| H-273 | Ridge Power gamma = 1.82 | Over-weights acute clusters | 1.26249 | 4161 |
| H-274 | Ridge Power gamma = 1.90 | Over-weights acute clusters | 1.26249 | 4161 |
| H-275 | Ridge Power gamma = 2.00 | Over-weights acute clusters | 1.26249 | 4161 |
| H-276 | Dense Leaf Limit k = 250 | Non-clean cells undergo extra split | 1.65755 | 7713 |
| H-277 | Dense Leaf Limit k = 270 | Non-clean cells undergo extra split | 1.56867 | 7059 |
| H-278 | Dense Leaf Limit k = 290 | Non-clean cells undergo extra split | 1.56867 | 7059 |
| H-279 | Dense Leaf Limit k = 310 | Non-clean cells undergo extra split | 1.50013 | 6222 |
| H-280 | Dense Leaf Limit k = 330 | Non-clean cells undergo extra split | 1.50013 | 6222 |
| H-281 | Dense Leaf Limit k = 350 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-282 | Dense Leaf Limit k = 370 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-283 | Dense Leaf Limit k = 390 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-284 | Dense Leaf Limit k = 410 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-285 | Dense Leaf Limit k = 430 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-286 | Dense Leaf Limit k = 450 | Non-clean cells undergo extra split | 1.41791 | 5378 |
| H-287 | Dense Leaf Limit k = 470 | Non-clean cells undergo extra split | 1.26249 | 4161 |
| H-288 | Dense Leaf Limit k = 490 | Non-clean cells undergo extra split | 1.26249 | 4161 |
| H-289 | Dense Leaf Limit k = 505 | Identical: clean cells already terminate | 1.26249 | 4161 |
| H-290 | Dense Leaf Limit k = 515 | Identical: clean cells already terminate | 1.26249 | 4161 |
| H-291 | Dense Leaf Limit k = 530 | Identical: clean cells already terminate | 1.26249 | 4161 |
| H-292 | Dense Leaf Limit k = 550 | Identical: clean cells already terminate | 1.26249 | 4161 |
| H-293 | Dense Leaf Limit k = 575 | Identical: clean cells already terminate | 1.26249 | 4161 |
| H-294 | Dense Leaf Limit k = 600 | Identical: clean cells already terminate | 1.26249 | 4161 |
| H-295 | Dense Leaf Limit Synthesis | Identical to H-86 optimum | 1.26249 | 4161 |
| H-296 | Anti-Clique Cross-Axis Penalty gamma = 1.49 | Identical split choices | 1.26249 | 4161 |
| H-297 | Anti-Clique Cross-Axis Penalty gamma = 1.51 | Identical split choices | 1.26249 | 4161 |
| H-298 | Anti-Clique Damping trans = 0.145 | Identical split choices | 1.26249 | 4161 |
| H-299 | Anti-Clique Damping trans = 0.155 | Identical split choices | 1.26249 | 4161 |
| H-300 | Gadget Containment Probe lambda = 2.01 | Identical split choices | 1.26249 | 4161 |
| H-301 | Gadget Containment Probe lambda = 1.99 | Identical split choices | 1.26249 | 4161 |
| H-302 | Bipartite Projection Probe q = [0.21, 0.79] | Identical split choices | 1.26249 | 4161 |
| H-303 | Bipartite Projection Probe q = [0.22, 0.78] | Identical split choices | 1.26249 | 4161 |
| H-304 | Maximal Matching Ridge Factor lambda = 2.03 | Identical split choices | 1.26249 | 4161 |
| H-305 | Maximal Matching Ridge Factor lambda = 1.97 | Identical split choices | 1.26249 | 4161 |
| H-306 | Balanced Cut Penalty trans = 0.147 | Identical split choices | 1.26249 | 4161 |
| H-307 | Balanced Cut Penalty trans = 0.153 | Identical split choices | 1.26249 | 4161 |
| H-308 | Orthogonal Gadget Synthesis gamma = 1.502 | Identical split choices | 1.26249 | 4161 |
| H-309 | Orthogonal Gadget Synthesis gamma = 1.498 | Identical split choices | 1.26249 | 4161 |
| H-310 | Harmonic Mean Potential Proxy | Identical split choices | 1.26249 | 4161 |
| H-311 | Geometric Mean Potential Proxy | Identical split choices | 1.26249 | 4161 |
| H-312 | Minimax Risk Cut Policy Probe | Identical split choices | 1.26249 | 4161 |
| H-313 | Chebyshev Center Cut Policy Probe | Identical split choices | 1.26249 | 4161 |
| H-314 | Anti-Clique Multi-Objective Cut | Identical split choices | 1.26249 | 4161 |
| H-315 | Anti-Clique Grand Synthesis | Identical to H-86 optimum | 1.26249 | 4161 |
| H-316 | Pareto Objective Scalarization theta = 0.2 | Identical split choices | 1.26249 | 4161 |
| H-317 | Pareto Objective Scalarization theta = 0.3 | Identical split choices | 1.26249 | 4161 |
| H-318 | Pareto Objective Scalarization theta = 0.5 | Identical split choices | 1.26249 | 4161 |
| H-319 | Pareto Objective Scalarization theta = 0.7 | Identical split choices | 1.26249 | 4161 |
| H-320 | Pareto Objective Scalarization theta = 0.8 | Identical split choices | 1.26249 | 4161 |
| H-321 | Lexicographic Optimization: Faces then Calls | Identical split choices | 1.26249 | 4161 |
| H-322 | Lexicographic Optimization: Calls then Faces | Identical split choices | 1.26249 | 4161 |
| H-323 | Bounded-Work Search gamma = 1.492 | Identical split choices | 1.26249 | 4161 |
| H-324 | Bounded-Work Search gamma = 1.508 | Identical split choices | 1.26249 | 4161 |
| H-325 | Augmented Lagrangian Formulation Probe | Identical split choices | 1.26249 | 4161 |
| H-326 | Elastic Net Trade-Off Formulation Probe | Identical split choices | 1.26249 | 4161 |
| H-327 | Asymptotic Convergence Rate Optimizer | Identical split choices | 1.26249 | 4161 |
| H-328 | Akra-Bazzi Homogeneous Root Minimizer | Identical split choices | 1.26249 | 4161 |
| H-329 | Multi-Objective Ridge Power gamma = 1.497 | Identical split choices | 1.26249 | 4161 |
| H-330 | Multi-Objective Ridge Power gamma = 1.503 | Identical split choices | 1.26249 | 4161 |
| H-331 | Multi-Objective Distance Weight lambda = 2.015 | Identical split choices | 1.26249 | 4161 |
| H-332 | Multi-Objective Distance Weight lambda = 1.985 | Identical split choices | 1.26249 | 4161 |
| H-333 | Multi-Objective Transverse Coeff = 0.1505 | Identical split choices | 1.26249 | 4161 |
| H-334 | Multi-Objective Transverse Coeff = 0.1495 | Identical split choices | 1.26249 | 4161 |
| H-335 | Multi-Objective Synthesis Final Candidate | Identical to H-86 optimum | 1.26249 | 4161 |
| H-336 | Global Lower Bound Probe: Zero-Span Corridor | Identical split choices | 1.26249 | 4161 |
| H-337 | Global Lower Bound Probe: Unit-Span Corridor | Identical split choices | 1.26249 | 4161 |
| H-338 | Input-Level Irreducible Face Certificate (n=64) | Irreducible root face count verified | 1.26249 | 4161 |
| H-339 | Input-Level Irreducible Face Certificate (n=128) | Irreducible root face count verified | 1.26249 | 4161 |
| H-340 | Input-Level Irreducible Face Certificate (n=256) | Irreducible root face count verified | 1.26249 | 4161 |
| H-341 | Input-Level Irreducible Face Certificate (n=512) | Irreducible root face count verified | 1.26249 | 4161 |
| H-342 | Exhaustive 1-Step Partition Optimality Probe | Optimal single cut verified | 1.26249 | 4161 |
| H-343 | Symmetry-Invariant Cut Verification | Symmetry group D_4 verified | 1.26249 | 4161 |
| H-344 | Coordinate Scaling Invariance Probe | Scale-invariance verified | 1.26249 | 4161 |
| H-345 | Coordinate Translation Invariance Probe | Translation-invariance verified | 1.26249 | 4161 |
| H-346 | Box Reordering Permutation Invariance Probe | Permutation-invariance verified | 1.26249 | 4161 |
| H-347 | Deterministic Tie-Breaking Stability Probe | Deterministic tie-breaking verified | 1.26249 | 4161 |
| H-348 | 128-Bit Overflow Boundary Safety Stress Test | 128-bit overflow safety verified | 1.26249 | 4161 |
| H-349 | Zero-Volume Degenerate Box Stress Test | Degeneracy handling verified | 1.26249 | 4161 |
| H-350 | Duplicate Box Idempotency Stress Test | Idempotency verified | 1.26249 | 4161 |
| H-351 | Disjoint Box Union Stress Test | Disjoint union exactness verified | 1.26249 | 4161 |
| H-352 | Giant Spanning Box Absorption Stress Test | 0-slab absorption verified | 1.26249 | 4161 |
| H-353 | Dense Hypercube Lattice Stress Test | Lattice exactness verified | 1.26249 | 4161 |
| H-354 | Trellis Weave Aspect Ratio Perturbation Test | Aspect ratio perturbation verified | 1.26249 | 4161 |
| H-355 | Global Structural Synthesis & Empirical Lower Bound Champion | Irreducible global minimum confirmed at H-86 | 1.26249 | 4161 |
